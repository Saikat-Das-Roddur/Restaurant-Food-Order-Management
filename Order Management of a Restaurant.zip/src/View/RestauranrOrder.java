/*
 * Copyright (c)
 * Author : Saikat Das
 * Created on : 10/22/19 8:03 PM
 * All rights reserved
 */

package View;

import View.MainFrame;

public class RestauranrOrder {
    public static void main(String[] args) {
        new MainFrame();
    }
}
