/*
 * Copyright (c)
 * Author : Saikat Das
 * Created on : 10/22/19 8:00 PM
 * All rights reserved
 */

package Model;

public enum Type {
    General,
    VIP,
    Guest
}
